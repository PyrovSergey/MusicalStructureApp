package com.test.musicalstructureapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


public class MainActivity extends AppCompatActivity {

    @BindView(R.id.text_name_of_album)
    TextView textNameOfAlbum;
    @BindView(R.id.text_name_song)
    TextView textNameSong;
    @BindView(R.id.button_play)
    ImageButton buttonPlay;
    @BindView(R.id.button_pause)
    ImageButton buttonPause;
    @BindView(R.id.button_forward)
    ImageButton buttonForward;
    @BindView(R.id.button_rewind)
    ImageButton buttonRewind;
    @BindView(R.id.button_list)
    ImageButton buttonList;
    @BindView(R.id.button_shuffle_off)
    ImageButton buttonShuffleOff;
    @BindView(R.id.button_shuffle_on)
    ImageButton buttonShuffleOn;
    @BindView(R.id.button_repeat_off)
    ImageButton buttonRepeatOff;
    @BindView(R.id.button_repeat_on)
    ImageButton buttonRepeatOn;

    List<Song> songs;

    public static int currentSong = 0;

    private boolean isShuffleON;

    private boolean isRepeatON;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        songs = SongFactory.getSongFactory();
        Log.e("MyTAG", String.valueOf(songs.size()));
        setSong(0);
    }

    @OnClick({R.id.text_name_of_album, R.id.text_name_song, R.id.button_play, R.id.button_pause, R.id.button_forward, R.id.button_rewind, R.id.button_list, R.id.button_shuffle_off, R.id.button_shuffle_on, R.id.button_repeat_off, R.id.button_repeat_on})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.button_play:
                buttonPlay.setVisibility(View.INVISIBLE);
                buttonPause.setVisibility(View.VISIBLE);
                break;
            case R.id.button_pause:
                buttonPlay.setVisibility(View.VISIBLE);
                buttonPause.setVisibility(View.INVISIBLE);
                break;
            case R.id.button_forward:
                buttonRepeatOff.setVisibility(View.VISIBLE);
                buttonRepeatOn.setVisibility(View.INVISIBLE);
                if (getButtonShuffleState()) {
                    int random = currentSong;
                    random = rnd(songs.size());
                    currentSong = random;
                    setSong(currentSong);
                } else {

                    currentSong++;
                    if (currentSong > songs.size() - 1) {
                        currentSong--;
                    }
                    setSong(currentSong);
                }
                break;
            case R.id.button_rewind:
                buttonRepeatOff.setVisibility(View.VISIBLE);
                buttonRepeatOn.setVisibility(View.INVISIBLE);
                currentSong--;
                if (currentSong < 0) {
                    currentSong = 0;
                }
                setSong(currentSong);
                break;
            case R.id.button_list:
                Intent intent = new Intent(this, SongsActivity.class);
                startActivity(intent);
                break;
            case R.id.button_shuffle_off:
                buttonShuffleOff.setVisibility(View.INVISIBLE);
                buttonShuffleOn.setVisibility(View.VISIBLE);
                break;
            case R.id.button_shuffle_on:
                buttonShuffleOff.setVisibility(View.VISIBLE);
                buttonShuffleOn.setVisibility(View.INVISIBLE);
                break;
            case R.id.button_repeat_off:
                buttonRepeatOff.setVisibility(View.INVISIBLE);
                buttonRepeatOn.setVisibility(View.VISIBLE);
                break;
            case R.id.button_repeat_on:
                buttonRepeatOff.setVisibility(View.VISIBLE);
                buttonRepeatOn.setVisibility(View.INVISIBLE);
                break;
        }
    }

    public void setSong(int id) {
        Song song = songs.get(id);
        textNameOfAlbum.setText(song.getAlbum());
        textNameSong.setText(song.getTitle());
    }

    public boolean getButtonShuffleState() {
        if (buttonShuffleOn.getVisibility() == View.VISIBLE) {
            return true;
        }
        return false;
    }

    public boolean getButtonRepeatState() {
        if (buttonRepeatOn.getVisibility() == View.VISIBLE) {
            return true;
        }
        return false;
    }

    public static int rnd(int max) {
        return (int) (Math.random() * max);
    }

    public static int getCurrentSong() {
        return currentSong;
    }

}
